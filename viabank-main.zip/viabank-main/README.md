# Via Bank — investimentos para empresas

Frontend HTML/CSS/JavaScript, API Java com Spring Boot e banco MySQL 8.0.
O administrador único cadastra empresas, atribui três notas e registra aportes.
As empresas acessam somente seus próprios dados, saldo, score e histórico.

## Iniciar com Docker

Na pasta que contém este README e `docker-compose.yml`:

1. Copie `.env.example` para `.env`.
2. Ajuste as senhas e o segredo JWT no `.env`.
3. Execute `docker compose up --build -d`.
4. Abra `http://localhost:8080/login.html`.

No Windows, pode copiar o arquivo pelo Explorador, ou usar
`Copy-Item .env.example .env` no PowerShell. No Linux/macOS: `cp .env.example .env`.

O acesso inicial é o `ADMIN_EMAIL` e o `ADMIN_PASSWORD` definidos no `.env`.
Com os valores de exemplo: **admin@viabank.com / Admin123!**.
A conta admin é criada somente se ainda não existe. Reiniciar o sistema ou
mudar o `.env` não troca a senha de um administrador já cadastrado.
Não há cadastro público ou opção para criar outro administrador.

O banco começa sem empresas e sem aportes fictícios. Crie uma empresa pelo
painel do admin; seu e-mail e senha já poderão ser usados na tela de login.
O cadastro exibe o resultado em um pop-up separado: fundo verde, amarelo ou
vermelho, texto branco e nenhuma nota numérica nessa página.

Para acompanhar a inicialização: `docker compose logs -f backend`.
Para parar sem perder os dados: `docker compose down`.

## O que fica no banco

| Tabela | Conteúdo |
| --- | --- |
| invest_users | Admin e contas empresariais, e-mail, senha BCrypt, perfil e versão de acesso |
| invest_companies | CNPJ, responsável, setor, três notas, score, classificação e saldo em centavos |
| invest_allocations | Empresa, valor, descrição, administrador responsável, data e identificação do aporte |
| invest_revoked_tokens | Sessões encerradas e expiração do token |
| flyway_schema_history | Migrações do banco aplicadas pelo backend |

As tabelas são criadas automaticamente por **Flyway**, antes de o backend
validar o esquema. `backend/database/01_schema.sql` é a referência da primeira
migração; não execute esse arquivo manualmente antes do Flyway.
O volume Docker `db_data` conserva os dados entre reinícios. Faça backup desse
volume/banco quando necessário; apagar o volume apaga os dados armazenados.

Os dados do antigo protótipo no navegador não são importados automaticamente.
Contas, senhas e aportes dessa versão passam a ser enviados à API e salvos no
MySQL. O navegador guarda somente o token de acesso da sessão; as listas em
memória da página são carregadas do servidor ao entrar e ao voltar à aba.

## Usar um banco já existente

A migração adiciona tabelas `invest_*` e preserva as tabelas antigas do banco
digital. Os endpoints antigos de cadastro público, PIX, cartões e depósitos
foram retirados da aplicação. A primeira migração pode ser aplicada em um
schema `via_bank` já existente; o baseline do Flyway está configurado em 0.

Se estiver reutilizando um volume MySQL criado pela versão anterior, as
variáveis `MYSQL_USER` e `MYSQL_PASSWORD` não criam usuários novamente em um
volume já inicializado. Configure `DB_USERNAME`/`DB_PASSWORD` para um usuário
existente com permissão nesse banco. Use a senha root já existente em
`MYSQL_ROOT_PASSWORD` para o healthcheck, ou crie o usuário `viabank` no MySQL.
Não é necessário apagar o volume para aplicar as tabelas novas.

O SQL legado de usuários pessoais não tem CNPJ nem as três notas. Não existe
conversão automática dessas contas para empresas ou migração de seus saldos.

## Regras

- Score: `(Plano financeiro + Participação + Utilidade) / 3`, notas de 0 a 10,
  com uma casa decimal por princípio. O front calcula na hora; o backend
  recalcula e persiste a avaliação, sem aceitar um score enviado pelo cliente.
- Aprovado: média >= 8; em análise: >= 4,5 e < 8; reprovado: < 4,5.
- A conta é salva nas três classificações. O status não impede aportes.
- CNPJ: 14 números, único; e-mail: único e normalizado. A aplicação não
  consulta o cadastro da Receita nem valida os dígitos verificadores do CNPJ.
- Senha empresarial: mínimo 8 caracteres, máximo 72 bytes (limite do BCrypt).
- Aporte: de R$ 0,01 a R$ 1 bilhão. Valor e saldo são inteiros em centavos.
- Aporte e saldo são gravados na mesma transação. Repetir o mesmo `requestId`
  com os mesmos dados retorna o aporte existente e não credita outra vez.
- Todos os aportes são atribuídos ao admin que os registrou.
- Empresa não pode criar, editar ou aportar; a API impõe essas permissões.
- Logout revoga o token no banco. Troca de senha pelo admin invalida os tokens
  anteriores da empresa. JWT expira por padrão após 60 minutos.

Os aportes representam créditos registrados no sistema. Não existe integração
com uma instituição financeira para movimentar dinheiro entre bancos.

## Executar sem Docker

Use Java 17 ou 21, MySQL 8.0.16+ e o Maven Wrapper incluído. Crie o banco
`via_bank` e um usuário com permissões de DDL/DML nesse schema. Exporte no
terminal/IDE as variáveis de `backend/.env.example` (Spring não lê `.env`
automaticamente fora do Docker).

Na pasta `backend`: `./mvnw spring-boot:run` (Windows: `mvnw.cmd spring-boot:run`).
Na pasta `frontend`, use o Live Server ou `python -m http.server 5500` e abra
`http://localhost:5500/login.html`. A API fica em `http://localhost:3000/api`.
Para hospedar em endereços diferentes, ajuste `frontend/config.js` e
`CORS_ALLOWED_ORIGINS`. Utilize HTTPS ao disponibilizar o sistema fora do
ambiente local, com credenciais próprias.

## Verificação

`cd backend` e `./mvnw test` executam testes com servidor HTTP real e H2 em modo
MySQL, aplicando a mesma migração SQL e validando as entidades Hibernate.
Os testes cobrem autenticação, permissões, isolamento das empresas, cadastro,
duplicidades, score e limites, aporte repetido/concorrente, saldo e histórico,
senhas protegidas, revogação, alteração de senha, único admin e restrições SQL.

Nesta versão, os testes HTTP passaram; o código do frontend também foi
executado contra a API real em H2, incluindo cadastro, pop-up, confirmação de
aporte, isolamento e recuperação de contas/saldos/histórico após reiniciar
o servidor com um banco H2 em arquivo. O JAR foi gerado com sucesso.

O teste H2 não substitui uma execução em MySQL: valide o ambiente Docker/MySQL
antes de disponibilizar a aplicação. A revisão visual em navegador também
continua necessária.
