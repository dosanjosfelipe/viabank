package br.com.viabank;
import br.com.viabank.config.AdminBootstrap;
import br.com.viabank.repository.UserRepository;
import com.fasterxml.jackson.databind.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.support.TransactionTemplate;
import java.net.*;
import java.net.http.*;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT,properties={
 "spring.datasource.url=jdbc:h2:mem:invest;MODE=MySQL;DB_CLOSE_DELAY=-1",
 "spring.datasource.username=sa","spring.datasource.password=","app.admin.email=admin@viabank.com",
 "app.admin.password=Admin123!","app.jwt.secret=integration-test-secret-with-more-than-32-bytes",
 "spring.jpa.hibernate.ddl-auto=validate"})
class InvestmentIntegrationTest {
 @LocalServerPort int port;
 @Autowired JdbcTemplate db;
 @Autowired org.flywaydb.core.Flyway flyway;
 @Autowired UserRepository users;
 @Autowired PasswordEncoder passwords;
 @Autowired TransactionTemplate tx;
 final ObjectMapper json=new ObjectMapper();
 final HttpClient client=HttpClient.newHttpClient();
 record Reply(int status,JsonNode body){}
 Reply request(String method,String path,String token,Object body)throws Exception{
   HttpRequest.Builder b=HttpRequest.newBuilder(URI.create("http://localhost:"+port+"/api"+path)).header("Accept","application/json");
   if(token!=null)b.header("Authorization","Bearer "+token);
   if(body!=null)b.header("Content-Type","application/json");
   b.method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofString(json.writeValueAsString(body)));
   var r=client.send(b.build(),HttpResponse.BodyHandlers.ofString());
   return new Reply(r.statusCode(),r.body().isBlank()?json.createObjectNode():json.readTree(r.body()));
 }
 String login(String email,String password)throws Exception{Reply r=request("POST","/auth/login",null,Map.of("email",email,"password",password));assertEquals(200,r.status(),r.body().toString());return r.body().get("accessToken").asText();}
 Map<String,Object> company(String email,String cnpj,double grade){return new HashMap<>(Map.of("name","Empresa Teste","email",email,"cnpj",cnpj,"responsible","Responsável","sector","Tecnologia","password","Empresa123!","grades",Map.of("financial",grade,"participation",grade,"utility",grade)));}
 @Test void completeWorkflowAndPermissions()throws Exception{
   assertEquals(401,request("GET","/workspace",null,null).status());
   assertEquals(401,request("POST","/auth/register",null,Map.of()).status());
   assertEquals(401,request("POST","/auth/login",null,Map.of("email","admin@viabank.com","password","wrong")).status());
   String admin=login("ADMIN@VIABANK.COM","Admin123!");
   assertEquals("admin",request("GET","/auth/me",admin,null).body().get("role").asText());
   var input=company("empresa@teste.com","12345678000190",8);
   Reply created=request("POST","/companies",admin,input);assertEquals(201,created.status(),created.body().toString());
   String id=created.body().get("id").asText();
   assertEquals("APPROVED",created.body().get("status").asText());assertEquals(8,created.body().get("score").asDouble());
   assertEquals(0,created.body().get("balanceCents").asLong());
   assertFalse(created.body().has("passwordHash"));
   assertEquals(409,request("POST","/companies",admin,input).status());
   var duplicateCnpj=company("different@teste.com","12345678000190",8);
   assertEquals(409,request("POST","/companies",admin,duplicateCnpj).status());
   input.put("role","ADMIN");assertEquals(400,request("POST","/companies",admin,input).status());input.remove("role");
   var invalid=company("invalid@teste.com","98765432000109",11);assertEquals(422,request("POST","/companies",admin,invalid).status());
   var ap=new HashMap<String,Object>(Map.of("companyId",id,"amountCents",150025,"note","Primeiro aporte","requestId",UUID.randomUUID().toString()));
   assertEquals(201,request("POST","/allocations",admin,ap).status());
   assertEquals(201,request("POST","/allocations",admin,ap).status());
   Reply snap=request("GET","/workspace",admin,null);assertEquals(1,snap.body().get("allocations").size());
   assertEquals(150025,snap.body().get("companies").get(0).get("balanceCents").asLong());
   ap.put("amountCents",3);assertEquals(409,request("POST","/allocations",admin,ap).status());
   ap.put("requestId",UUID.randomUUID().toString());ap.put("amountCents",1.5);assertEquals(400,request("POST","/allocations",admin,ap).status());
   ap.put("amountCents",-1);assertEquals(422,request("POST","/allocations",admin,ap).status());
   // Requisições concorrentes, todas com a mesma identificação, creditam uma vez.
   ap.put("amountCents",100);ap.put("requestId",UUID.randomUUID().toString());
   try(ExecutorServiceClose executor=new ExecutorServiceClose()){
     List<Future<Reply>> futures=new ArrayList<>();for(int i=0;i<4;i++)futures.add(executor.service.submit(()->request("POST","/allocations",admin,ap)));
     for(var future:futures)assertEquals(201,future.get().status());
   }
   assertEquals(150125,db.queryForObject("select balance_cents from invest_companies where id=?",Long.class,Long.valueOf(id)));
   assertEquals(2,db.queryForObject("select count(*) from invest_allocations",Integer.class));
   String companyToken=login("empresa@teste.com","Empresa123!");
   assertEquals(403,request("POST","/companies",companyToken,input).status());
   assertEquals(403,request("PUT","/companies/"+id,companyToken,input).status());
   assertEquals(403,request("POST","/allocations",companyToken,ap).status());
   // Os dois limites da classificação são testados com contas reais no banco.
   for(int i=0;i<6;i++){
     double grade=new double[]{0,4.4,4.5,7.9,8,10}[i];
     String expected=new String[]{"REJECTED","REJECTED","IN_ANALYSIS","IN_ANALYSIS","APPROVED","APPROVED"}[i];
     Reply result=request("POST","/companies",admin,company("score"+i+"@teste.com","8765432100010"+i,grade));
     assertEquals(201,result.status(),result.body().toString());assertEquals(expected,result.body().get("status").asText());
   }
   Reply own=request("GET","/workspace",companyToken,null);
   assertEquals(1,own.body().get("companies").size());assertEquals(id,own.body().get("companies").get(0).get("id").asText());assertEquals(2,own.body().get("allocations").size());
   input.put("password","");input.put("name","Empresa Atualizada");
   assertEquals(200,request("PUT","/companies/"+id,admin,input).status());
   assertEquals(200,request("GET","/workspace",companyToken,null).status());
   input.put("password","NovaEmpresa123!");assertEquals(200,request("PUT","/companies/"+id,admin,input).status());
   assertEquals(401,request("GET","/workspace",companyToken,null).status());
   companyToken=login("empresa@teste.com","NovaEmpresa123!");
   assertEquals(200,request("POST","/auth/logout",companyToken,null).status());
   assertEquals(401,request("GET","/workspace",companyToken,null).status());
   String hash=db.queryForObject("select password_hash from invest_users where email='empresa@teste.com'",String.class);
   assertTrue(hash.startsWith("$2"));assertNotEquals("NovaEmpresa123!",hash);
   assertThrows(org.springframework.dao.DataIntegrityViolationException.class,()->db.update("insert into invest_users(name,email,password_hash,role,admin_slot,auth_version,enabled,created_at,updated_at) values('Segundo','segundo@teste.com','x','ADMIN',1,0,true,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)"));
   assertThrows(org.springframework.dao.DataIntegrityViolationException.class,()->db.update("update invest_companies set financial=11 where id=?",Long.valueOf(id)));
   // Reexecutar o inicializador não cria outra conta nem redefine a senha.
   new AdminBootstrap().bootstrapAdmin(users,passwords,tx,"outro@teste.com","OutraSenha123!").run(null);
   assertEquals(1,db.queryForObject("select count(*) from invest_users where role='ADMIN'",Integer.class));
   assertEquals("1",flyway.info().current().getVersion().getVersion());
 }
 static class ExecutorServiceClose implements AutoCloseable {final ExecutorService service=Executors.newFixedThreadPool(4);public void close(){service.shutdown();}}
}
