package br.com.viabank.service;
import br.com.viabank.domain.UserRole;
import br.com.viabank.dto.invest.InvestDtos.*;
import br.com.viabank.entity.*;
import br.com.viabank.exception.*;
import br.com.viabank.repository.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
import java.nio.charset.StandardCharsets;
@Service
public class InvestService {
    public static final long MAX_SAFE_CENTS=9007199254740991L;
    private final UserRepository users;private final CompanyRepository companies;private final AllocationRepository allocations;
    private final CurrentUserService current;private final PasswordEncoder passwords;
    public InvestService(UserRepository u,CompanyRepository c,AllocationRepository a,CurrentUserService me,PasswordEncoder p){users=u;companies=c;allocations=a;current=me;passwords=p;}
    public User requireAdmin(){User user=current.get();if(user.getRole()!=UserRole.ADMIN)throw new ForbiddenException("Somente o administrador pode realizar esta ação.");return user;}
    @Transactional(readOnly=true)
    public UserView me(){return userView(current.get());}
    public UserView userView(User u){return new UserView(u.getId().toString(),u.getRole()==UserRole.ADMIN?"admin":"company",u.getName(),u.getEmail(),companies.findByUserId(u.getId()).map(c->c.id.toString()).orElse(null));}
    @Transactional(readOnly=true)
    public Snapshot snapshot(){
        User me=current.get();
        if(me.getRole()==UserRole.ADMIN)return new Snapshot(companies.findAllByOrderByCreatedAtDesc().stream().map(this::view).toList(),allocations.findAllByOrderByCreatedAtDesc().stream().map(this::view).toList());
        Company company=companies.findByUserId(me.getId()).orElseThrow(()->new NotFoundException("Conta empresarial não encontrada."));
        return new Snapshot(List.of(view(company)),allocations.findByCompanyIdOrderByCreatedAtDesc(company.id).stream().map(this::view).toList());
    }
    @Transactional(isolation=org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public CompanyView save(CompanyRequest request,Long id){
        User admin=requireAdmin();
        // Serializa alterações administrativas e aportes, inclusive edições concorrentes.
        users.lockById(admin.getId()).orElseThrow();
        Company company=id==null?new Company():companies.lockById(id).orElseThrow(()->new NotFoundException("Empresa não encontrada."));
        String email=request.email().trim().toLowerCase(Locale.ROOT);
        String cnpj=request.cnpj().replaceAll("\\D","");
        if(cnpj.length()!=14)throw new BusinessException("O CNPJ deve ter 14 números.");
        if(request.name().trim().length()<2)throw new BusinessException("Informe o nome da empresa.");
        users.findByEmailIgnoreCase(email).filter(u->company.user==null||!u.getId().equals(company.user.getId())).ifPresent(u->{throw new ConflictException("Este e-mail já está em uso.");});
        companies.findByCnpj(cnpj).filter(c->!c.id.equals(company.id)).ifPresent(c->{throw new ConflictException("Já existe uma empresa com este CNPJ.");});
        if(id==null){company.user=new User();company.user.setRole(UserRole.COMPANY);company.createdBy=admin;}
        String password=request.password();
        if(id==null||password!=null&&!password.isEmpty()){
            if(password==null||password.length()<8||password.getBytes(StandardCharsets.UTF_8).length>72)throw new BusinessException("A senha deve ter no mínimo 8 caracteres e no máximo 72 bytes.");
            company.user.setPasswordHash(passwords.encode(password));
            if(id!=null)company.user.invalidateSessions();
        }
        company.user.setEmail(email);company.user.setName(request.name().trim());users.save(company.user);
        company.cnpj=cnpj;company.responsible=request.responsible().trim();company.sector=request.sector().trim();
        company.financial=request.grades().financial();company.participation=request.grades().participation();company.utility=request.grades().utility();
        companies.saveAndFlush(company);
        return view(company);
    }
    @Transactional(isolation=org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public AllocationView allocate(AllocationRequest request){
        User admin=requireAdmin();users.lockById(admin.getId()).orElseThrow();
        String note=request.note()==null||request.note().isBlank()?"Aporte de capital":request.note().trim();
        long companyId;try{companyId=Long.parseLong(request.companyId());}catch(NumberFormatException e){throw new BusinessException("Empresa inválida.");}
        Optional<Allocation> previous=allocations.findByRequestId(request.requestId().toString());
        if(previous.isPresent()){
            Allocation a=previous.get();
            if(!a.company.id.equals(companyId) || a.amountCents!=request.amountCents() || !a.note.equals(note))throw new ConflictException("A identificação deste aporte já foi usada com outros dados.");
            return view(a);
        }
        Company company=companies.lockById(companyId).orElseThrow(()->new NotFoundException("Empresa não encontrada."));
        long amount=request.amountCents();
        if(amount<1||amount>100000000000L||companies.totalBalance()>MAX_SAFE_CENTS-amount)throw new BusinessException("O valor excede o limite permitido.");
        company.balanceCents=Math.addExact(company.balanceCents,amount);
        Allocation allocation=new Allocation();allocation.company=company;allocation.createdBy=admin;allocation.amountCents=amount;allocation.note=note;allocation.requestId=request.requestId().toString();
        allocations.saveAndFlush(allocation);companies.saveAndFlush(company);
        return view(allocation);
    }
    private CompanyView view(Company c){String cnpj=c.cnpj.replaceFirst("(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})","$1.$2.$3/$4-$5");return new CompanyView(c.id.toString(),c.user.getName(),cnpj,c.user.getEmail(),c.responsible,c.sector,new Grades(c.financial,c.participation,c.utility),c.score,c.status,c.balanceCents,c.createdAt);}
    private AllocationView view(Allocation a){return new AllocationView(a.id.toString(),a.company.id.toString(),a.amountCents,a.note,a.createdAt);}
}
