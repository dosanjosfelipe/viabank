package br.com.viabank.entity;
import jakarta.persistence.*;
import java.math.*;
import java.time.Instant;
@Entity @Table(name="invest_companies",uniqueConstraints={@UniqueConstraint(columnNames="cnpj"),@UniqueConstraint(columnNames="user_id")})
public class Company {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
    @OneToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="user_id",nullable=false) public User user;
    @Column(nullable=false,length=14) public String cnpj;
    @Column(nullable=false,length=100) public String responsible;
    @Column(nullable=false,length=80) public String sector;
    @Column(nullable=false,precision=3,scale=1) public BigDecimal financial;
    @Column(nullable=false,precision=3,scale=1) public BigDecimal participation;
    @Column(nullable=false,precision=3,scale=1) public BigDecimal utility;
    @Column(nullable=false,precision=10,scale=8) public BigDecimal score;
    @Column(nullable=false,length=16) public String status;
    @Column(name="balance_cents",nullable=false) public long balanceCents;
    @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="created_by",nullable=false) public User createdBy;
    @Version public long version;
    @Column(name="created_at",nullable=false,updatable=false) public Instant createdAt;
    @Column(name="updated_at",nullable=false) public Instant updatedAt;
    @PrePersist void create(){createdAt=Instant.now();update();}
    @PreUpdate void update(){
        updatedAt=Instant.now();
        BigDecimal sum=financial.add(participation).add(utility);
        score=sum.divide(BigDecimal.valueOf(3),8,RoundingMode.HALF_UP);
        status=sum.compareTo(BigDecimal.valueOf(24))>=0?"APPROVED":sum.compareTo(new BigDecimal("13.5"))>=0?"IN_ANALYSIS":"REJECTED";
    }
}
