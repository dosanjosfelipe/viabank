package br.com.viabank.repository;
import br.com.viabank.entity.User;
import br.com.viabank.domain.UserRole;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import java.util.Optional;
public interface UserRepository extends JpaRepository<User,Long> {
    Optional<User> findByEmailIgnoreCase(String email);
    Optional<User> findByRole(UserRole role);
    @Lock(LockModeType.PESSIMISTIC_WRITE) @Query("select u from User u where u.id = :id") Optional<User> lockById(Long id);
}
