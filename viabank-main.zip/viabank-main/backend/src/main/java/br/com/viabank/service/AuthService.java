package br.com.viabank.service;
import br.com.viabank.dto.auth.LoginRequest;
import br.com.viabank.dto.invest.InvestDtos.LoginView;
import br.com.viabank.entity.*;
import br.com.viabank.repository.*;
import br.com.viabank.security.JwtService;
import org.springframework.security.authentication.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Locale;
@Service
public class AuthService {
    private final UserRepository users;private final RevokedTokenRepository revoked;private final AuthenticationManager authentication;private final JwtService jwt;private final InvestService invest;
    public AuthService(UserRepository u,RevokedTokenRepository r,AuthenticationManager a,JwtService j,InvestService i){users=u;revoked=r;authentication=a;jwt=j;invest=i;}
    @Transactional(readOnly=true)
    public LoginView login(LoginRequest request){
        String email=request.email().trim().toLowerCase(Locale.ROOT);
        authentication.authenticate(new UsernamePasswordAuthenticationToken(email,request.password()));
        User user=users.findByEmailIgnoreCase(email).orElseThrow(()->new BadCredentialsException("Credenciais inválidas."));
        return new LoginView(jwt.generateToken(user.getId(),user.getAuthVersion()),jwt.getExpirationSeconds(),invest.userView(user));
    }
    @Transactional
    public void logout(String header){
        if(header==null||!header.startsWith("Bearer "))return;
        String token=header.substring(7),jti=jwt.getJti(token);
        if(jti==null||revoked.existsByJti(jti))return;
        RevokedToken r=new RevokedToken();r.setJti(jti);r.setExpiresAt(jwt.getExpiration(token));revoked.save(r);
    }
}
