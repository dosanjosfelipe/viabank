package br.com.viabank.entity;
import br.com.viabank.domain.UserRole;
import jakarta.persistence.*;
import org.hibernate.annotations.Check;
import java.time.Instant;
@Entity
@Table(name="invest_users",uniqueConstraints={@UniqueConstraint(columnNames="email"),@UniqueConstraint(columnNames="admin_slot")})
@Check(constraints="(role = 'ADMIN' AND admin_slot IS NOT NULL AND admin_slot = 1) OR (role = 'COMPANY' AND admin_slot IS NULL)")
public class User {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false,length=100) private String name;
    @Column(nullable=false,length=160) private String email;
    @Column(name="password_hash",nullable=false,length=100) private String passwordHash;
    @Enumerated(EnumType.STRING) @Column(nullable=false,length=16) private UserRole role;
    @Column(name="admin_slot") private Short adminSlot;
    @Column(name="auth_version",nullable=false) private long authVersion;
    @Column(nullable=false) private boolean enabled=true;
    @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
    @Column(name="updated_at",nullable=false) private Instant updatedAt;
    @PrePersist void create(){createdAt=Instant.now();updatedAt=createdAt;}
    @PreUpdate void update(){updatedAt=Instant.now();}
    public Long getId(){return id;} public String getName(){return name;} public String getEmail(){return email;}
    public String getPasswordHash(){return passwordHash;} public UserRole getRole(){return role;}
    public long getAuthVersion(){return authVersion;} public boolean isEnabled(){return enabled;}
    public void setName(String v){name=v;} public void setEmail(String v){email=v;}
    public void setPasswordHash(String v){passwordHash=v;} public void setRole(UserRole v){role=v;adminSlot=v==UserRole.ADMIN?(short)1:null;}
    public void invalidateSessions(){authVersion++;}
}
