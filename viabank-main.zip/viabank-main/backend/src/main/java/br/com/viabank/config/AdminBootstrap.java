package br.com.viabank.config;
import br.com.viabank.domain.UserRole;
import br.com.viabank.entity.User;
import br.com.viabank.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.support.TransactionTemplate;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
@Configuration
public class AdminBootstrap {
    @Bean public ApplicationRunner bootstrapAdmin(UserRepository users,PasswordEncoder encoder,TransactionTemplate tx,
        @Value("${app.admin.email}") String email,@Value("${app.admin.password}") String password){
        return args->tx.executeWithoutResult(status->{
            if(users.findByRole(UserRole.ADMIN).isPresent())return;
            String normalized=email.trim().toLowerCase(Locale.ROOT);
            if(!normalized.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+")||normalized.length()>160||password.length()<8||password.getBytes(StandardCharsets.UTF_8).length>72)throw new IllegalStateException("Configure ADMIN_EMAIL e ADMIN_PASSWORD (mínimo 8 caracteres, máximo 72 bytes) para o primeiro acesso.");
            User admin=new User();admin.setName("Administrador");admin.setEmail(normalized);admin.setRole(UserRole.ADMIN);admin.setPasswordHash(encoder.encode(password));users.saveAndFlush(admin);
        });
    }
}
