package br.com.viabank.controller;
import br.com.viabank.dto.auth.LoginRequest;
import br.com.viabank.dto.common.MessageResponse;
import br.com.viabank.dto.invest.InvestDtos.*;
import br.com.viabank.service.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;private final InvestService invest;
    public AuthController(AuthService a,InvestService i){auth=a;invest=i;}
    @PostMapping("/login") public LoginView login(@Valid @RequestBody LoginRequest r){return auth.login(r);}
    @PostMapping("/logout") public MessageResponse logout(HttpServletRequest r){auth.logout(r.getHeader("Authorization"));return new MessageResponse("Sessão encerrada.");}
    @GetMapping("/me") public UserView me(){return invest.me();}
}
