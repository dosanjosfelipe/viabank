package br.com.viabank.repository;
import br.com.viabank.entity.Company;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import java.util.*;
public interface CompanyRepository extends JpaRepository<Company,Long> {
    @EntityGraph(attributePaths="user") List<Company> findAllByOrderByCreatedAtDesc();
    @EntityGraph(attributePaths="user") Optional<Company> findByUserId(Long userId);
    Optional<Company> findByCnpj(String cnpj);
    @Lock(LockModeType.PESSIMISTIC_WRITE) @Query("select c from Company c where c.id = :id") Optional<Company> lockById(Long id);
    @Query("select coalesce(sum(c.balanceCents),0) from Company c") long totalBalance();
}
