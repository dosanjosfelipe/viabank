package br.com.viabank.repository;
import br.com.viabank.entity.Allocation;
import org.springframework.data.jpa.repository.*;
import java.util.*;
public interface AllocationRepository extends JpaRepository<Allocation,Long> {
    @EntityGraph(attributePaths="company") List<Allocation> findAllByOrderByCreatedAtDesc();
    @EntityGraph(attributePaths="company") List<Allocation> findByCompanyIdOrderByCreatedAtDesc(Long companyId);
    @EntityGraph(attributePaths="company") Optional<Allocation> findByRequestId(String requestId);
}
