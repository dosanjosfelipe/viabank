package br.com.viabank.dto.invest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;
public final class InvestDtos {
    private InvestDtos(){}
    public record Grades(
        @NotNull @DecimalMin("0") @DecimalMax("10") @Digits(integer=2,fraction=1) BigDecimal financial,
        @NotNull @DecimalMin("0") @DecimalMax("10") @Digits(integer=2,fraction=1) BigDecimal participation,
        @NotNull @DecimalMin("0") @DecimalMax("10") @Digits(integer=2,fraction=1) BigDecimal utility){}
    public record CompanyRequest(
        @NotBlank @Size(min=2,max=100) String name,
        @NotBlank @Size(max=18) @Pattern(regexp="[0-9./-]+") String cnpj,
        @NotBlank @Email @Size(max=160) String email,
        @NotBlank @Size(max=100) String responsible,
        @NotBlank @Size(max=80) String sector,
        @Size(max=128) String password,
        @NotNull @Valid Grades grades){}
    public record AllocationRequest(
        @NotBlank @Pattern(regexp="[0-9]+") String companyId,
        @NotNull @Min(1) @Max(100000000000L) Long amountCents,
        @Size(max=180) String note,
        @NotNull UUID requestId){}
    public record CompanyView(String id,String name,String cnpj,String email,String responsible,String sector,
                              Grades grades,BigDecimal score,String status,long balanceCents,Instant createdAt){}
    public record AllocationView(String id,String companyId,long amountCents,String note,Instant createdAt){}
    public record Snapshot(List<CompanyView> companies,List<AllocationView> allocations){}
    public record UserView(String id,String role,String name,String email,String companyId){}
    public record LoginView(String accessToken,long expiresIn,UserView user){}
}
