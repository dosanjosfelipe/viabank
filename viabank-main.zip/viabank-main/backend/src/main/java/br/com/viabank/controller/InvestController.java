package br.com.viabank.controller;
import br.com.viabank.dto.invest.InvestDtos.*;
import br.com.viabank.service.InvestService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api")
public class InvestController {
    private final InvestService invest;public InvestController(InvestService i){invest=i;}
    @GetMapping("/workspace") public Snapshot workspace(){return invest.snapshot();}
    @PostMapping("/companies") @ResponseStatus(HttpStatus.CREATED) public CompanyView create(@Valid @RequestBody CompanyRequest r){return invest.save(r,null);}
    @PutMapping("/companies/{id}") public CompanyView update(@PathVariable Long id,@Valid @RequestBody CompanyRequest r){return invest.save(r,id);}
    @PostMapping("/allocations") @ResponseStatus(HttpStatus.CREATED) public AllocationView allocate(@Valid @RequestBody AllocationRequest r){return invest.allocate(r);}
}
