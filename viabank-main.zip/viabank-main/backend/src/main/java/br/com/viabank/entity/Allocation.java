package br.com.viabank.entity;
import jakarta.persistence.*;
import java.time.Instant;
@Entity @Table(name="invest_allocations",uniqueConstraints=@UniqueConstraint(columnNames="request_id"))
public class Allocation {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
    @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="company_id",nullable=false) public Company company;
    @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="created_by",nullable=false) public User createdBy;
    @Column(name="amount_cents",nullable=false) public long amountCents;
    @Column(nullable=false,length=180) public String note;
    @Column(name="request_id",nullable=false,length=36) public String requestId;
    @Column(name="created_at",nullable=false,updatable=false) public Instant createdAt;
    @PrePersist void create(){createdAt=Instant.now();}
}
