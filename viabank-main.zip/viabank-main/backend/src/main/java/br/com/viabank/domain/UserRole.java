package br.com.viabank.domain;
public enum UserRole { ADMIN, COMPANY }
