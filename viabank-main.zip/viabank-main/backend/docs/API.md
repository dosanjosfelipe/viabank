# API Via Bank de investimentos

Prefixo: `/api`. JSON. Bearer JWT nas rotas protegidas. IDs são strings no JSON;
valores monetários são números inteiros em centavos, nunca reais decimais.

| Método | Rota | Acesso | Retorno |
| --- | --- | --- | --- |
| POST | /auth/login | Público | accessToken, expiresIn, user |
| GET | /auth/me | Autenticado | id, role, name, email, companyId |
| POST | /auth/logout | Autenticado | Revoga token atual |
| GET | /workspace | Autenticado | companies e allocations autorizadas |
| POST | /companies | Admin | Conta criada, HTTP 201 |
| PUT | /companies/{id} | Admin | Empresa atualizada |
| POST | /allocations | Admin | Aporte registrado ou já existente, HTTP 201 |

`role`: `admin` ou `company`. `companyId` é null para admin. Empresa recebe uma
única empresa e somente seus aportes em `/workspace`. Não há `/auth/register`.

## Login

```json
{"email":"admin@viabank.com","password":"senha-configurada"}
```

## Empresa

```json
{
  "name":"Minha Empresa",
  "cnpj":"12345678000190",
  "email":"contato@empresa.com",
  "responsible":"Nome do responsável",
  "sector":"Tecnologia",
  "password":"Empresa123!",
  "grades":{"financial":8,"participation":9,"utility":7}
}
```

Para edição, `password` pode ser vazio/ausente para manter a senha. As notas
são obrigatórias e aceitam no máximo uma casa decimal. Campos desconhecidos
como `role`, `balanceCents` ou `score` não são aceitos. Backend calcula score.
O retorno inclui `grades`, `score`, `status`, `balanceCents` e `createdAt`,
sem senha ou hash. `status`: APPROVED, IN_ANALYSIS ou REJECTED.

## Aporte

```json
{
  "companyId":"1",
  "amountCents":150025,
  "note":"Expansão da operação",
  "requestId":"28bf8c96-85a6-4dc9-849b-43d557eec301"
}
```

Retorno: `id`, `companyId`, `amountCents`, `note`, `createdAt`.
`requestId` é UUID obrigatório: preserve-o ao repetir uma requisição cujo
resultado ficou incerto. Repetição com os mesmos dados não duplica o crédito;
a mesma identificação com outros dados retorna 409. O total de saldos é
limitado a 9007199254740991 centavos para manter a precisão no frontend.

## Erros

- 400: JSON malformado, tipos incompatíveis ou regra de negócio inválida.
- 401: credenciais incorretas, token ausente, expirado ou revogado.
- 403: perfil sem autorização.
- 404: empresa inexistente.
- 409: e-mail/CNPJ repetido ou conflito na identificação do aporte.
- 422: campos inválidos, notas fora do intervalo ou valor fora dos limites.

Erros incluem `message` e, quando há validação de campos, `fields`.
