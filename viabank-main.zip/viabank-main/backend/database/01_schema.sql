-- Tabelas novas para investimentos; preserva tabelas do banco digital anterior.
CREATE TABLE invest_users (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(160) NOT NULL,
 password_hash VARCHAR(100) NOT NULL,
 role VARCHAR(16) NOT NULL,
 admin_slot SMALLINT NULL,
 auth_version BIGINT NOT NULL DEFAULT 0,
 enabled BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMP(6) NOT NULL,
 updated_at TIMESTAMP(6) NOT NULL,
 CONSTRAINT uk_invest_users_email UNIQUE(email),
 CONSTRAINT uk_invest_single_admin UNIQUE(admin_slot),
 CONSTRAINT ck_invest_user_role CHECK ((role = 'ADMIN' AND admin_slot IS NOT NULL AND admin_slot = 1) OR (role = 'COMPANY' AND admin_slot IS NULL))
);
CREATE TABLE invest_companies (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT NOT NULL,
 cnpj VARCHAR(14) NOT NULL,
 responsible VARCHAR(100) NOT NULL,
 sector VARCHAR(80) NOT NULL,
 financial DECIMAL(3,1) NOT NULL,
 participation DECIMAL(3,1) NOT NULL,
 utility DECIMAL(3,1) NOT NULL,
 score DECIMAL(10,8) NOT NULL,
 status VARCHAR(16) NOT NULL,
 balance_cents BIGINT NOT NULL DEFAULT 0,
 created_by BIGINT NOT NULL,
 version BIGINT NOT NULL DEFAULT 0,
 created_at TIMESTAMP(6) NOT NULL,
 updated_at TIMESTAMP(6) NOT NULL,
 CONSTRAINT uk_invest_company_user UNIQUE(user_id),
 CONSTRAINT uk_invest_company_cnpj UNIQUE(cnpj),
 CONSTRAINT fk_invest_company_user FOREIGN KEY(user_id) REFERENCES invest_users(id),
 CONSTRAINT fk_invest_company_creator FOREIGN KEY(created_by) REFERENCES invest_users(id),
 CONSTRAINT ck_invest_grades CHECK (financial BETWEEN 0 AND 10 AND participation BETWEEN 0 AND 10 AND utility BETWEEN 0 AND 10),
 CONSTRAINT ck_invest_score CHECK (score BETWEEN 0 AND 10),
 CONSTRAINT ck_invest_status CHECK (status IN ('APPROVED','IN_ANALYSIS','REJECTED')),
 CONSTRAINT ck_invest_balance CHECK (balance_cents BETWEEN 0 AND 9007199254740991)
);
CREATE TABLE invest_allocations (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 company_id BIGINT NOT NULL,
 created_by BIGINT NOT NULL,
 amount_cents BIGINT NOT NULL,
 note VARCHAR(180) NOT NULL,
 request_id VARCHAR(36) NOT NULL,
 created_at TIMESTAMP(6) NOT NULL,
 CONSTRAINT uk_invest_request UNIQUE(request_id),
 CONSTRAINT fk_invest_allocation_company FOREIGN KEY(company_id) REFERENCES invest_companies(id),
 CONSTRAINT fk_invest_allocation_creator FOREIGN KEY(created_by) REFERENCES invest_users(id),
 CONSTRAINT ck_invest_allocation_amount CHECK (amount_cents BETWEEN 1 AND 100000000000)
);
CREATE INDEX idx_invest_allocations_company ON invest_allocations(company_id,created_at);
CREATE TABLE invest_revoked_tokens (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 jti VARCHAR(36) NOT NULL,
 expires_at TIMESTAMP(6) NOT NULL,
 revoked_at TIMESTAMP(6) NOT NULL,
 CONSTRAINT uk_revoked_tokens_jti UNIQUE(jti)
);
CREATE INDEX idx_invest_revoked_expires ON invest_revoked_tokens(expires_at);
