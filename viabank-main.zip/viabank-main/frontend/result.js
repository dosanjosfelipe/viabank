'use strict';
(() => {
  const params=new URLSearchParams(window.location.search);
  const statuses={
    high:{label:'APROVADO',background:'#238443'},
    mid:{label:'EM ANALISE',background:'#ac8000'},
    low:{label:'REPROVADO',background:'#c13f3f'},
    pending:{label:'PREPARANDO RESULTADO',background:'#142620'}
  };
  const status=params.get('status');
  const result=Object.hasOwn(statuses,status)?statuses[status]:{label:'RESULTADO INDISPONÍVEL',background:'#142620'};
  document.body.dataset.status=Object.hasOwn(statuses,status)?status:'unknown';
  document.getElementById('resultTitle').textContent=result.label;
  document.getElementById('themeColor').setAttribute('content',result.background);
  document.title=`Via Bank | ${result.label}`;
  const company=document.getElementById('resultCompany');
  const companyName=params.get('company');
  if(companyName && ['high','mid','low'].includes(status)) {
    company.textContent=companyName;
    company.hidden=false;
  }
  const button=document.getElementById('closeResult');
  button.hidden=status==='pending';
  button.addEventListener('click',()=>{
    window.close();
    document.getElementById('closeHint').hidden=false;
  });
})();
