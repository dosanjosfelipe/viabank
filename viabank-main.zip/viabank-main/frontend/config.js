// Opcional: defina a URL pública do backend quando front e API estiverem em servidores diferentes.
// window.VIA_API_BASE_URL = 'https://sua-api.example/api';
