/* API autenticada. Docker usa /api pelo proxy; Live Server usa a porta 3000. */
window.ViaAPI=(()=>{
  const TOKEN='via_invest_access_token';
  const defaultBase=window.location.port==='8080'?'/api':`${window.location.protocol}//${window.location.hostname}:3000/api`;
  const base=(window.VIA_API_BASE_URL||defaultBase).replace(/\/$/,'');
  const token=()=>sessionStorage.getItem(TOKEN);
  function clear(){sessionStorage.removeItem(TOKEN);}
  async function request(path,{method='GET',body}={}){
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);
    try{
      const headers={Accept:'application/json'};
      if(body!==undefined)headers['Content-Type']='application/json';
      if(token())headers.Authorization=`Bearer ${token()}`;
      const response=await fetch(base+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:controller.signal,credentials:'omit'});
      const payload=await response.json().catch(()=>null);
      if(!response.ok){
        const fields=payload?.fields?Object.values(payload.fields).join('; '):'';
        const error=new Error(fields||payload?.message||`Não foi possível concluir a operação (HTTP ${response.status}).`);error.status=response.status;
        if(response.status===401&&path!=='/auth/login'){clear();window.location.replace('login.html');}
        throw error;
      }
      return payload;
    }catch(error){
      if(error.status)throw error;
      throw new Error(error.name==='AbortError'?'O servidor demorou para responder. Tente novamente.':'Não foi possível conectar ao servidor. Verifique se o backend está iniciado.');
    }finally{clearTimeout(timer);}
  }
  async function login(email,password){const result=await request('/auth/login',{method:'POST',body:{email,password}});sessionStorage.setItem(TOKEN,result.accessToken);return result.user;}
  async function logout(){try{if(token())await request('/auth/logout',{method:'POST'});}finally{clear();}}
  return {request,login,logout,hasSession:()=>Boolean(token()),clear};
})();
