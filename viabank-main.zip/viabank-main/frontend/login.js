'use strict';
const loginForm = document.getElementById('loginForm');
document.getElementById('togglePassword').addEventListener('click',event=>{
  const input=document.getElementById('loginPassword');
  input.type=input.type==='password'?'text':'password';
  event.target.textContent=input.type==='password'?'Mostrar':'Ocultar';
  event.target.setAttribute('aria-label',input.type==='password'?'Mostrar senha':'Ocultar senha');
});
loginForm.addEventListener('submit',async event=>{
  event.preventDefault();
  const button=document.getElementById('loginSubmit');
  const error=document.getElementById('loginError');
  button.disabled=true;button.textContent='Acessando…';error.hidden=true;
  try { await ViaStore.login(loginForm.email.value,loginForm.password.value);window.location.assign('index.html'); }
  catch(e) { error.textContent=e.message;error.hidden=false; }
  finally { button.disabled=false;button.innerHTML='Acessar minha conta <span>↗</span>'; }
});
