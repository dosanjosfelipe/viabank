# Frontend Via Bank

Esta versão usa o backend e o banco; consulte o README da raiz para iniciar.

- `backend.js`: chamadas autenticadas à API, erro e token de sessão.
- `store.js`: adaptação dos dados retornados pelo servidor para as telas.
- `app.js`: telas, formulário, score imediato, aporte e exportação.
- `login.js`: login com as credenciais cadastradas no servidor.
- `result.html`, `result.css`, `result.js`: pop-up de classificação, sem score,
  fundo da cor correspondente e texto branco.
- `config.js`: URL opcional da API para uma hospedagem diferente.

Com Docker, o nginx encaminha `/api` para o backend. Com Live Server na porta
5500, a API padrão é `http://localhost:3000/api`. Não existe mais login demo,
contas fictícias iniciais ou persistência das empresas em localStorage.
O acesso inicial é definido nas variáveis ADMIN_EMAIL e ADMIN_PASSWORD.

O navegador pode bloquear pop-ups ou abri-los como abas. A aplicação solicita
uma janela durante o clique de cadastro e oferece um link caso a abertura
seja bloqueada. O resultado só é apresentado depois que a API confirma o
cadastro; um erro fecha a janela de preparação.
