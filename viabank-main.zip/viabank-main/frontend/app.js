'use strict';
const $ = selector => document.querySelector(selector);
const escapeHTML = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = cents => (cents/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const decimal = value => value.toLocaleString('pt-BR',{minimumFractionDigits:1,maximumFractionDigits:1});
const dateLabel = value => new Date(value).toLocaleDateString('pt-BR',{day:'2-digit',month:'short',year:'numeric'});
const initials = name => name.split(/\s+/).slice(0,2).map(n=>n[0]).join('').toUpperCase();
const iconPaths = {
  overview:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  companies:'<path d="M4 21V5l8-2v18M12 9h8v12M2 21h20M7 8h2M7 12h2M7 16h2M15 13h2M15 17h2"/>',
  allocations:'<path d="M4 17l6-6 4 4 6-10M14 5h6v6M3 21h18"/>',
  score:'<circle cx="12" cy="12" r="9"/><path d="M8 14l4-6 4 6M10 12h4"/>',
  history:'<path d="M6 3h12v18H6zM9 7h6M9 11h6M9 15h4"/>',
  logout:'<path d="M10 4H4v16h6M14 8l4 4-4 4M8 12h10"/>',
  search:'<circle cx="10" cy="10" r="6"/><path d="M15 15l6 6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  arrow:'<path d="M6 18L18 6M6 6h12v12"/>',
  help:'<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 016 0c0 2-3 2-3 4M12 16v1"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>'
};
const icon = name => `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name]||iconPaths.arrow}</svg>`;
let user, view='overview', search='', sort='newest', snapshot, modalReturnFocus;
let toastTimer;
function toast(text) { $('#toast').textContent=text;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),4200); }
function brand() { return '<div class="brand"><span class="brand-mark">v<span>↗</span></span><div>via<span class="brand-bank">bank</span><small>INVESTIMENTOS</small></div></div>'; }
function scoreClassification(score) {
  if (score >= 8) return {label:'APROVADO',tone:'high'};
  if (score >= 4.5) return {label:'EM ANALISE',tone:'mid'};
  return {label:'REPROVADO',tone:'low'};
}
function scoreChip(score) { return `<span class="score-chip ${scoreClassification(score).tone}"><i></i>${decimal(score)}<small>/ 10</small></span>`; }
function companyIdentity(c) { return `<div class="company-identity"><span class="company-avatar color-${snapshot.companies.findIndex(x=>x.id===c.id)%4}">${escapeHTML(initials(c.name))}</span><div><strong>${escapeHTML(c.name)}</strong><small>${escapeHTML(c.sector)}</small></div></div>`; }
function go(next) {
  const allowed=user.role==='admin'?['overview','companies','allocations','score','history','method']:['overview','score','history','method'];
  view=allowed.includes(next)?next:'overview';search='';sort='newest';render();window.scrollTo({top:0,behavior:'smooth'});
}
function render() {
  snapshot=ViaStore.data();
  const admin=user.role==='admin';
  const titles={overview:'Visão geral',companies:'Empresas',allocations:'Aportes',score:'Score de potencial',history:'Movimentações',method:'Como funciona o score'};
  const nav=admin?[['overview','Visão geral'],['companies','Empresas'],['allocations','Aportes'],['score','Score de potencial'],['history','Movimentações']]:[['overview','Minha conta'],['score','Meu score'],['history','Movimentações']];
  $('#app').innerHTML=`<div class="app-shell"><button class="sidebar-overlay" aria-label="Fechar menu" data-action="close-menu"></button><aside class="sidebar"><div>${brand()}<div class="workspace-label">${admin?'GESTÃO DE INVESTIMENTOS':'ESPAÇO DA EMPRESA'}</div><nav>${nav.map(([key,label])=>`<button class="nav-item ${view===key?'active':''}" data-page="${key}" ${view===key?'aria-current="page"':''}>${icon(key)}${label}${key==='companies'?`<span class="nav-count">${snapshot.companies.length}</span>`:''}</button>`).join('')}</nav></div><div class="sidebar-bottom"><div class="sidebar-callout"><span class="tiny-star">✳</span><strong>Ideias com futuro.<br>Capital com propósito.</strong><small>Cada empresa, uma nova possibilidade.</small></div><button class="nav-item ${view==='method'?'active':''}" data-page="method">${icon('help')}Entenda o score</button><div class="user-profile"><span class="user-avatar">${admin?'AD':escapeHTML(initials(user.name))}</span><div><strong>${admin?'Administrador':escapeHTML(user.name)}</strong><small>${admin?'Acesso de gestão':'Conta empresarial'}</small></div><button class="logout-btn" data-action="logout" aria-label="Sair da conta">${icon('logout')}</button></div></div></aside>
  <main class="main"><header class="topbar"><div class="topbar-left"><button class="icon-btn menu-btn" data-action="menu" aria-label="Abrir menu">${icon('menu')}</button><span>Workspace <b>/</b> <strong>${titles[view]}</strong></span></div><span class="badge"><i></i> Conta conectada</span></header><div class="page-content"><div class="page-heading"><div><p class="eyebrow">${admin?'VIA BANK · PAINEL ADMINISTRATIVO':'VIA BANK · CONTA EMPRESARIAL'}</p><h1>${view==='overview'?(admin?'Investir no futuro começa aqui.':`Olá, ${escapeHTML(user.name)}.`):titles[view]}</h1><p class="muted">${({overview:admin?'Uma visão completa das empresas e do capital que movimenta novas ideias.':'Acompanhe o capital recebido e o potencial da sua empresa.',companies:'Empresas que você conhece. Potencial que você acompanha.',allocations:'Direcione capital para o próximo capítulo de cada empresa.',score:'Três princípios. Uma visão clara do potencial de cada negócio.',history:'Todos os aportes, com clareza do início ao fim.',method:'Uma avaliação transparente, com o mesmo peso para cada princípio.'})[view]}</p></div>${admin&&view!=='method'?`<button class="btn primary" data-action="${view==='allocations'?'allocate':'create'}">${icon('plus')}${view==='allocations'?'Novo aporte':'Nova empresa'}</button>`:''}</div><div id="pageBody">${({overview:overview,companies:companiesPage,allocations:allocationsPage,score:scorePage,history:historyPage,method:methodPage})[view]()}</div><footer class="page-footer"><span>via bank <b>·</b> Investimentos para ir além.</span><span>Dados registrados na Via Bank</span></footer></div></main></div>`;
}
function overview() {
  const admin=user.role==='admin';
  const total=snapshot.companies.reduce((sum,c)=>sum+c.balanceCents,0);
  const average=snapshot.companies.length?snapshot.companies.reduce((sum,c)=>sum+c.score,0)/snapshot.companies.length:0;
  const metrics=admin?[
    ['Capital alocado',money(total),'Total de aportes para as empresas','allocations'],
    ['Empresas na carteira',snapshot.companies.length.toString(),'Contas criadas pelo administrador','companies'],
    ['Score médio',`${decimal(average)} <small>/ 10</small>`,'Média dos três princípios','score'],
    ['Aportes realizados',snapshot.allocations.length.toString(),'Movimentações registradas','history']
  ]:[['Capital recebido',money(total),'Saldo disponível na sua conta','allocations'],['Score da empresa',`${decimal(average)} <small>/ 10</small>`,'Avaliação feita pela equipe Via Bank','score'],['Aportes recebidos',snapshot.allocations.length.toString(),'Investimento no seu negócio','history']];
  return `<div class="metrics ${admin?'':'three'}">${metrics.map(([label,value,note,ic],i)=>`<article class="metric ${i===0?'featured':''}"><div><span>${label}</span>${icon(ic)}</div><strong>${value}</strong><small>${note}</small>${i===0?'<div class="metric-decoration" aria-hidden="true">↗</div>':''}</article>`).join('')}</div>
    <div class="overview-grid"><article class="panel chart-panel"><div class="section-title"><div><p class="eyebrow">CAPITAL EM MOVIMENTO</p><h2>${admin?'Aportes na carteira':'Aportes recebidos'}</h2></div><span class="subtle-tag">Últimos 6 meses</span></div>${capitalChart()}</article><article class="potential-card"><div><span class="outline-tag">${admin?'INVISTA EM POTENCIAL':'SEU POTENCIAL EM FOCO'}</span><h2>${admin?'Oportunidades têm nome. E propósito.':'Grandes ideias merecem o próximo passo.'}</h2><p>${admin?'Conheça cada empresa além dos números. Avalie, acompanhe e invista com intenção.':'Plano financeiro, participação e utilidade. Conheça os pilares da sua avaliação.'}</p></div><button class="text-btn" data-page="${admin?'score':'method'}">${admin?'Explorar scores':'Entender meu score'} ${icon('arrow')}</button><div class="potential-art" aria-hidden="true"><i></i><i></i><i></i></div></article></div>
    ${admin?`<article class="panel company-panel"><div class="section-title"><div><p class="eyebrow">NOSSA CARTEIRA</p><h2>Empresas em destaque <span class="count-pill">${snapshot.companies.length}</span></h2></div><button class="text-btn" data-page="companies">Ver todas as empresas →</button></div>${companyTable([...snapshot.companies].sort((a,b)=>b.score-a.score).slice(0,4))}</article>`:companySummary(snapshot.companies[0])}
    <article class="panel"><div class="section-title"><div><p class="eyebrow">ÚLTIMAS MOVIMENTAÇÕES</p><h2>Capital que chegou</h2></div><button class="text-btn" data-page="history">Ver histórico →</button></div>${historyList(5)}</article>`;
}
function capitalChart() {
  const now=new Date();
  const months=Array.from({length:6},(_,i)=>new Date(now.getFullYear(),now.getMonth()-5+i,1));
  const values=months.map(m=>snapshot.allocations.filter(a=>{const d=new Date(a.createdAt);return d.getFullYear()===m.getFullYear()&&d.getMonth()===m.getMonth();}).reduce((s,a)=>s+a.amountCents,0));
  const max=Math.max(...values,100);
  const sum=values.reduce((s,v)=>s+v,0);
  return `<div class="chart-summary"><strong>${money(sum)}</strong><span>Total no período</span></div><div class="bar-chart" role="img" aria-label="Aportes por mês: ${values.map((v,i)=>`${months[i].toLocaleDateString('pt-BR',{month:'long'})}: ${money(v)}`).join('; ')}"><div class="chart-grid"><i></i><i></i><i></i><i></i></div>${values.map((value,i)=>`<div class="chart-column"><div class="chart-bar ${i===5?'current':''}" style="height:${Math.max(value>0?5:0,value/max*100)}%"><span>${money(value)}</span></div><small>${months[i].toLocaleDateString('pt-BR',{month:'short'}).replace('.','')}</small></div>`).join('')}</div><div class="chart-legend"><i></i> Aportes mensais <span>Sem projeção de rendimento</span></div>`;
}
function companyTable(list) {
  if (!list.length) return '<div class="empty-state"><span>↗</span><h3>Nenhuma empresa por aqui</h3><p>Cadastre uma empresa para começar sua carteira.</p><button class="btn primary" data-action="create">Cadastrar empresa</button></div>';
  return `<div class="table-scroll"><table><thead><tr><th>Empresa</th><th>CNPJ</th><th>Score</th><th>Capital recebido</th><th><span class="sr-only">Ações</span></th></tr></thead><tbody>${list.map(c=>`<tr><td>${companyIdentity(c)}</td><td class="muted cnpj">${escapeHTML(c.cnpj)}</td><td>${scoreChip(c.score)}</td><td class="table-money">${money(c.balanceCents)}</td><td><button class="row-btn" data-action="details" data-id="${c.id}" aria-label="Ver ${escapeHTML(c.name)}">${icon('arrow')}</button></td></tr>`).join('')}</tbody></table></div>`;
}
function companiesPage() {
  return `<article class="panel"><div class="list-toolbar"><div class="search-field">${icon('search')}<input id="companySearch" type="search" placeholder="Buscar nome, CNPJ ou setor" aria-label="Buscar empresas" value="${escapeHTML(search)}"></div><div class="toolbar-right"><span class="muted">${snapshot.companies.length} empresas</span><select id="companySort" aria-label="Ordenar empresas"><option value="newest">Mais recentes</option><option value="score">Maior score</option><option value="name">Nome: A a Z</option></select></div></div><div id="companiesResults">${filteredCompanies()}</div></article>`;
}
function filteredCompanies() {
  const normalize=v=>v.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const needle=normalize(search);
  const list=snapshot.companies.filter(c=>normalize(`${c.name} ${c.cnpj} ${c.cnpj.replace(/\D/g,'')} ${c.sector}`).includes(needle));
  list.sort(sort==='score'?(a,b)=>b.score-a.score:sort==='name'?(a,b)=>a.name.localeCompare(b.name,'pt-BR'):(a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  return list.length?companyTable(list):'<div class="empty-state"><h3>Nenhuma empresa encontrada</h3><p>Tente outro nome, CNPJ ou setor.</p></div>';
}
function allocationsPage() {
  const total=snapshot.allocations.reduce((s,a)=>s+a.amountCents,0);
  return `<div class="allocation-banner"><div><p class="eyebrow">CAPITAL DIRECIONADO</p><h2>${money(total)}</h2><p>Investimento distribuído entre ${snapshot.companies.length} empresas.</p></div><span class="banner-arrow" aria-hidden="true">↗</span></div><div class="section-title"><h2>Para onde vamos investir?</h2><span class="muted">Selecione uma empresa para fazer um aporte</span></div><div class="company-card-grid">${snapshot.companies.map(c=>`<article class="panel allocation-company">${companyIdentity(c)}<div class="allocation-data"><span>Capital recebido<strong>${money(c.balanceCents)}</strong></span>${scoreChip(c.score)}</div><button class="btn secondary full" data-action="allocate" data-id="${c.id}">Fazer aporte ${icon('arrow')}</button></article>`).join('')||'<p class="muted">Cadastre uma empresa antes de fazer o primeiro aporte.</p>'}</div>`;
}
function criterionBars(c) { return [['financial','Plano financeiro'],['participation','Participação'],['utility','Utilidade']].map(([key,label])=>`<div class="criterion-row"><div><span>${label}</span><strong>${decimal(c.grades[key])}<small>/ 10</small></strong></div><div class="progress-track"><i style="width:${c.grades[key]*10}%"></i></div></div>`).join(''); }
function scorePage() {
  const list=[...snapshot.companies].sort((a,b)=>b.score-a.score);
  return `<div class="score-intro"><div><span class="badge neutral">MÉDIA SIMPLES · 3 PRINCÍPIOS</span><h2>O valor de uma empresa<br>vai além do seu saldo.</h2><p class="muted">Cada princípio recebe uma nota de 0 a 10.<br>O score final é a média das três avaliações.</p></div><div class="formula-card"><span>Plano financeiro + Participação + Utilidade</span><div class="formula-line"></div><strong>3</strong><small>= Score de 0 a 10</small></div></div><div class="score-grid">${list.map((c,i)=>`<article class="panel score-company"><div class="section-title">${companyIdentity(c)}${user.role==='admin'?`<span class="rank">#${i+1}</span>`:''}</div><div class="score-big"><strong>${decimal(c.score)}</strong><span>/ 10<small>Score de potencial</small></span></div>${criterionBars(c)}${user.role==='admin'?`<button class="text-btn" data-action="edit" data-id="${c.id}">Revisar avaliação →</button>`:'<p class="small-note">Avaliação atribuída pela equipe Via Bank.</p>'}</article>`).join('')}</div>`;
}
function companySummary(c) { return `<article class="panel"><div class="section-title"><div><p class="eyebrow">SUA EMPRESA</p><h2>Potencial em três princípios</h2></div>${scoreChip(c.score)}</div><div class="company-score-columns">${criterionBars(c)}</div><p class="small-note">Seu score é a média de Plano financeiro, Participação e Utilidade. Para revisar a avaliação, converse com a equipe Via Bank.</p></article>`; }
function historyList(limit) {
  const list=[...snapshot.allocations].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,limit);
  return list.length?`<div class="transaction-list">${list.map(a=>{const company=snapshot.companies.find(c=>c.id===a.companyId);return `<div class="transaction"><span class="transaction-icon">↙</span><div><strong>${escapeHTML(company?.name||'Empresa')}</strong><small>${escapeHTML(a.note)} · ${dateLabel(a.createdAt)}</small></div><div class="transaction-value"><strong>+ ${money(a.amountCents)}</strong><small>Aporte recebido</small></div></div>`;}).join('')}</div>`:'<div class="empty-state"><h3>O primeiro aporte ainda está por vir.</h3><p>As movimentações aparecerão aqui.</p></div>';
}
function historyPage() { return `<article class="panel"><div class="section-title"><div><p class="eyebrow">HISTÓRICO DE APORTES</p><h2>${snapshot.allocations.length} movimentações</h2></div><button class="btn secondary" data-action="export" ${snapshot.allocations.length?'':'disabled'}>Exportar CSV ↓</button></div>${historyList()}</article>`; }
function methodPage() { return `<article class="panel method-panel"><span class="badge neutral">AVALIAÇÃO DE 0 A 10</span><h2>Três pilares, o mesmo peso.</h2><p class="muted">A equipe atribui as notas durante o cadastro da empresa, com base no atendimento presencial. O score ajuda a comparar avaliações; ele não é uma garantia de retorno.</p><div class="method-grid">${[['01','Plano financeiro','Organização financeira, planejamento do uso do capital e viabilidade do negócio.'],['02','Participação','Envolvimento da empresa, compromisso com o projeto e participação nas atividades acordadas.'],['03','Utilidade','Relevância da solução, benefício gerado e contribuição para o público atendido.']].map(([n,title,text])=>`<div><span>${n}</span><h3>${title}</h3><p>${text}</p><small>Peso: 1 de 3</small></div>`).join('')}</div><div class="method-example"><p class="eyebrow">UM EXEMPLO PRÁTICO</p><h3>(8 + 9 + 7) ÷ 3 = <span>8,0</span></h3><p>O cálculo usa a média completa. A interface exibe uma casa decimal.</p></div></article>`; }
function openModal(content) {
  modalReturnFocus=document.activeElement;
  $('#modal').innerHTML=`<button class="modal-close" data-action="close" aria-label="Fechar janela">×</button>${content}`;
  $('#modal').showModal();
}
function modalError(message) { const box=$('#modalError');if(box){box.textContent=message;box.hidden=false;}else toast(message); }
function prepareResultPopup() {
  try {
    // Abrir durante o clique de cadastro, antes de aguardar o salvamento.
    const popup=window.open('result.html?status=pending','_blank','popup=yes,width=820,height=560,resizable=yes,scrollbars=yes');
    if (popup) popup.opener=null;
    return popup;
  } catch { return null; }
}
function companyCreationResult(id,popup) {
  const company=snapshot.companies.find(c=>c.id===id);
  if (!company) return;
  const result=scoreClassification(company.score);
  const url=new URL('result.html',window.location.href);
  url.searchParams.set('status',result.tone);
  url.searchParams.set('company',company.name);
  try {
    if(popup && !popup.closed) {
      popup.location.replace(url.href);
      popup.focus();
      return;
    }
  } catch { /* Disponibilizar uma abertura manual se a janela não estiver acessível. */ }
  openModal(`<p class="eyebrow">CONTA CRIADA</p><h2 id="modalTitle">Abra o resultado</h2><p class="muted">O navegador não abriu o pop-up automaticamente. Clique abaixo para ver o resultado em uma página separada.</p><a class="btn primary" href="${escapeHTML(url.href)}" target="_blank" rel="noopener noreferrer">Abrir resultado ↗</a>`);
}
function companyForm(id) {
  if (user.role!=='admin') return;
  const c=snapshot.companies.find(c=>c.id===id);
  openModal(`<p class="eyebrow">${c?'REVISAR EMPRESA':'UMA NOVA POSSIBILIDADE'}</p><h2 id="modalTitle">${c?'Editar empresa':'Cadastrar empresa'}</h2><p class="muted">${c?'Atualize os dados e a avaliação da empresa.':'Crie uma conta após o atendimento presencial.'}</p><form id="companyForm" class="form-stack" data-id="${c?.id||''}"><div class="form-grid"><label class="span-two">Nome da empresa<input name="name" required minlength="2" maxlength="100" value="${escapeHTML(c?.name||'')}" placeholder="Ex.: Aurora Energia"></label><label>CNPJ<input name="cnpj" required inputmode="numeric" maxlength="18" value="${escapeHTML(c?.cnpj||'')}" placeholder="00.000.000/0000-00"></label><label>Setor<select name="sector" required>${['Tecnologia','Energia','Alimentação','Mobilidade','Saúde','Educação','Comércio','Serviços','Outros'].map(s=>`<option ${c?.sector===s?'selected':''}>${s}</option>`).join('')}</select></label><label>Responsável<input name="responsible" required maxlength="100" value="${escapeHTML(c?.responsible||'')}" placeholder="Nome do responsável"></label><label>E-mail de acesso<input name="email" type="email" required maxlength="160" value="${escapeHTML(c?.email||'')}" placeholder="contato@empresa.com"></label><label class="span-two">${c?'Nova senha (opcional)':'Senha de acesso'}<input name="password" type="password" ${c?'':'required'} minlength="8" maxlength="72" autocomplete="new-password" placeholder="${c?'Deixe em branco para manter a atual':'Mínimo de 8 caracteres'}"></label></div><fieldset class="score-fields"><legend>Avaliação de potencial</legend><p>Notas de 0 a 10, com o mesmo peso.</p><div class="grade-grid">${[['financial','Plano financeiro'],['participation','Participação'],['utility','Utilidade']].map(([key,label])=>`<label>${label}<input name="${key}" type="number" min="0" max="10" step="0.1" required placeholder="0 a 10" value="${c?.grades[key]??''}"></label>`).join('')}</div><div class="live-score"><div><strong>Score calculado</strong><small>(Plano financeiro + Participação + Utilidade) ÷ 3</small></div><output id="liveScore">${c?decimal(c.score):'—'}<small> / 10</small></output></div></fieldset><p id="modalError" class="form-error" role="alert" hidden></p><div class="modal-actions"><button class="btn secondary" type="button" data-action="close">Cancelar</button><button class="btn primary" type="submit">${c?'Salvar alterações':'Criar conta da empresa'} ${icon('arrow')}</button></div></form>`);
  const form=$('#companyForm');
  form.addEventListener('input',()=>{try { $('#liveScore').innerHTML=`${decimal(ViaStore.score(readGrades(form)))}<small> / 10</small>`; }catch {$('#liveScore').innerHTML='—<small> / 10</small>';} });
  form.addEventListener('submit',async event=>{
    event.preventDefault();const button=form.querySelector('[type=submit]');button.disabled=true;
    let resultPopup;
    try {
      const data=new FormData(form);const input=Object.fromEntries(data);input.grades=readGrades(form);
      ViaStore.score(input.grades);
      if(!c) resultPopup=prepareResultPopup();
      const savedId=await ViaStore.saveCompany(input,form.dataset.id||undefined);
      $('#modal').close();render();
      if(c) toast('Empresa atualizada.');
      else { companyCreationResult(savedId,resultPopup);toast('Conta criada. Compartilhe o e-mail e a senha com a empresa.'); }
    }
    catch(e){try{resultPopup?.close();}catch{}modalError(e.message);}finally{button.disabled=false;}
  });
}
function readGrades(form) { return Object.fromEntries(['financial','participation','utility'].map(k=>[k,form.elements[k].value.trim()===''?NaN:Number(form.elements[k].value)])); }
function details(id) {
  const c=snapshot.companies.find(c=>c.id===id);if(!c)return;
  openModal(`<p class="eyebrow">CONTA EMPRESARIAL</p><h2 id="modalTitle">${escapeHTML(c.name)}</h2><p class="muted">${escapeHTML(c.sector)} · ${escapeHTML(c.cnpj)}</p><div class="detail-balance"><span>Capital recebido</span><strong>${money(c.balanceCents)}</strong>${scoreChip(c.score)}</div><div class="detail-info"><div><span>Responsável</span><strong>${escapeHTML(c.responsible)}</strong></div><div><span>E-mail de acesso</span><strong>${escapeHTML(c.email)}</strong></div><div><span>Cadastro</span><strong>${dateLabel(c.createdAt)}</strong></div></div>${criterionBars(c)}<div class="modal-actions"><button class="btn secondary" data-action="edit" data-id="${c.id}">Editar empresa</button><button class="btn primary" data-action="allocate" data-id="${c.id}">Fazer aporte ${icon('arrow')}</button></div>`);
}
function parseCents(raw) {
  raw=raw.trim();
  if(!/^(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{1,2})?$/.test(raw)) throw new Error('Use um valor como 1.500,00, com até duas casas decimais.');
  const [whole,fraction='']=raw.replace(/\./g,'').split(',');
  const cents=Number(whole)*100+Number(fraction.padEnd(2,'0'));
  if(!Number.isSafeInteger(cents)||cents<=0||cents>100000000000)throw new Error('Informe um valor de R$ 0,01 até R$ 1 bilhão.');
  return cents;
}
function allocationForm(id) {
  if(user.role!=='admin')return;
  if(!snapshot.companies.length){toast('Cadastre uma empresa antes de fazer um aporte.');return;}
  openModal(`<p class="eyebrow">INVESTIR NO PRÓXIMO PASSO</p><h2 id="modalTitle">Novo aporte</h2><p class="muted">O valor será creditado no saldo da empresa selecionada.</p><form id="allocationForm" class="form-stack"><label>Empresa<select name="companyId" required>${snapshot.companies.map(c=>`<option value="${c.id}" ${c.id===id?'selected':''}>${escapeHTML(c.name)}</option>`).join('')}</select></label><div class="allocation-preview" id="allocationPreview"></div><label>Valor do aporte (R$)<input name="amount" inputmode="decimal" placeholder="Ex.: 5.000,00" required maxlength="24"></label><label>Descrição<input name="note" placeholder="Ex.: Expansão da operação" maxlength="180"></label><p id="modalError" class="form-error" role="alert" hidden></p><div class="modal-actions"><button class="btn secondary" type="button" data-action="close">Cancelar</button><button class="btn primary" type="submit">Revisar aporte →</button></div></form>`);
  const form=$('#allocationForm');
  const preview=()=>{const c=snapshot.companies.find(c=>c.id===form.companyId.value);$('#allocationPreview').innerHTML=`<span>Saldo atual <strong>${money(c.balanceCents)}</strong></span>${scoreChip(c.score)}`;};preview();form.companyId.addEventListener('change',preview);
  form.addEventListener('submit',event=>{
    event.preventDefault();
    try{const amount=parseCents(form.amount.value);confirmAllocation(form.companyId.value,amount,form.note.value);}catch(e){modalError(e.message);}
  });
}
function confirmAllocation(id,amount,note) {
  const c=snapshot.companies.find(c=>c.id===id);
  $('#modal').innerHTML=`<button class="modal-close" data-action="close" aria-label="Fechar janela">×</button><p class="eyebrow">CONFIRMAÇÃO DO APORTE</p><h2 id="modalTitle">Um novo passo para<br>${escapeHTML(c.name)}.</h2><div class="confirm-amount">${money(amount)}</div><div class="detail-info"><div><span>Empresa</span><strong>${escapeHTML(c.name)}</strong></div><div><span>Descrição</span><strong>${escapeHTML(note||'Aporte de capital')}</strong></div><div><span>Saldo após aporte</span><strong>${money(c.balanceCents+amount)}</strong></div></div><p class="small-note">O valor será creditado na conta da empresa e registrado no histórico.</p><p id="modalError" class="form-error" role="alert" hidden></p><div class="modal-actions"><button class="btn secondary" id="backAllocation">Voltar</button><button class="btn primary" id="confirmAllocation">Confirmar aporte ${icon('arrow')}</button></div>`;
  $('#backAllocation').onclick=()=>{allocationForm(id);$('#allocationForm').amount.value=(amount/100).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});$('#allocationForm').note.value=note;};
  $('#confirmAllocation').focus();
  const requestId=crypto.randomUUID();
  $('#confirmAllocation').onclick=async event=>{const button=event.currentTarget;button.disabled=true;try{await ViaStore.allocate(id,amount,note,requestId);$('#modal').close();render();toast(`Aporte de ${money(amount)} registrado para ${c.name}.`);}catch(e){modalError(e.message);button.disabled=false;}};
}
function exportCSV() {
  const safe=value=>`"${String(value).replace(/^[=+@\-\t\r]/,"'$&").replace(/"/g,'""')}"`;
  const lines=[['Data','Empresa','CNPJ','Valor (R$)','Descrição'],...snapshot.allocations.map(a=>{const c=snapshot.companies.find(c=>c.id===a.companyId);return [new Date(a.createdAt).toLocaleString('pt-BR'),c.name,c.cnpj,(a.amountCents/100).toFixed(2).replace('.',','),a.note];})];
  const blob=new Blob(['\uFEFF'+lines.map(row=>row.map(safe).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='viabank-aportes.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Histórico exportado.');
}
document.addEventListener('click',event=>{
  const button=event.target.closest('button');if(!button)return;
  if(button.dataset.page){go(button.dataset.page);return;}
  const action=button.dataset.action;const id=button.dataset.id;
  if(action==='logout'){button.disabled=true;ViaStore.logout().catch(()=>{}).finally(()=>window.location.replace('login.html'));}
  if(action==='create')companyForm();
  if(action==='edit')companyForm(id);
  if(action==='details')details(id);
  if(action==='allocate')allocationForm(id);
  if(action==='close')$('#modal').close();
  if(action==='export')exportCSV();
  if(action==='menu')$('.app-shell').classList.toggle('menu-open');
  if(action==='close-menu')$('.app-shell').classList.remove('menu-open');
});
document.addEventListener('input',event=>{if(event.target.id==='companySearch'){search=event.target.value;$('#companiesResults').innerHTML=filteredCompanies();}});
document.addEventListener('change',event=>{if(event.target.id==='companySort'){sort=event.target.value;$('#companiesResults').innerHTML=filteredCompanies();}});
$('#modal').addEventListener('click',event=>{if(event.target===$('#modal')){const r=$('#modal').getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)$('#modal').close();}});
$('#modal').addEventListener('close',()=>{if($('#modal').open)return;if(modalReturnFocus?.isConnected)modalReturnFocus.focus();else $('.page-heading button')?.focus();});
document.addEventListener('visibilitychange',async()=>{if(document.visibilityState==='visible'&&user&&!$('#modal').open){try{await ViaStore.refresh();render();}catch(error){if(error.status===401)window.location.replace('login.html');else toast(error.message);}}});
(async()=>{
  try{await ViaStore.init();user=ViaStore.currentUser();if(!user){window.location.replace('login.html');return;}render();}
  catch(e){$('#app').innerHTML=`<main class="boot"><h1>Não foi possível abrir sua conta.</h1><p>${escapeHTML(e.message)}</p><a href="login.html">Voltar ao acesso</a></main>`;}
})();
