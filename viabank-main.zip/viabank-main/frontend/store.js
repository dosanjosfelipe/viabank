/* Adaptador da API: contas, notas, score, saldos e aportes são persistidos no banco. */
window.ViaStore=(()=>{
  'use strict';
  let user=null,state={companies:[],allocations:[]};
  const score=grades=>{
    const values=['financial','participation','utility'].map(key=>grades[key]);
    if(values.some(v=>typeof v!=='number'||!Number.isFinite(v)||v<0||v>10))throw new Error('Informe três notas válidas entre 0 e 10.');
    return values.reduce((sum,v)=>sum+v,0)/3;
  };
  function adminOnly(){if(user?.role!=='admin')throw new Error('Somente o administrador pode realizar esta ação.');}
  async function init(){
    if(!ViaAPI.hasSession()){user=null;return;}
    try{user=await ViaAPI.request('/auth/me');await refresh();}
    catch(error){if(error.status===401){user=null;return;}throw error;}
  }
  async function refresh(){state=await ViaAPI.request('/workspace');if(user?.role==='company'){const company=state.companies.find(c=>c.id===user.companyId);if(company)Object.assign(user,{name:company.name,email:company.email});}return data();}
  async function login(email,password){user=await ViaAPI.login(email.trim().toLowerCase(),password);}
  function data(){if(!user)throw new Error('Acesse sua conta para continuar.');return structuredClone(state);}
  async function saveCompany(input,id){
    adminOnly();score(input.grades);
    if(input.password&&(input.password.length<8||new TextEncoder().encode(input.password).length>72))throw new Error('A senha deve ter no mínimo 8 caracteres e no máximo 72 bytes.');
    const body={name:input.name.trim(),cnpj:input.cnpj.replace(/\D/g,''),email:input.email.trim().toLowerCase(),responsible:input.responsible.trim(),sector:input.sector.trim(),password:input.password||'',grades:input.grades};
    const company=await ViaAPI.request(id?`/companies/${encodeURIComponent(id)}`:'/companies',{method:id?'PUT':'POST',body});
    // Atualização local reflete apenas a resposta já confirmada pelo servidor.
    state.companies=state.companies.filter(c=>c.id!==company.id);state.companies.unshift(company);
    return company.id;
  }
  async function allocate(companyId,amountCents,note,requestId){
    adminOnly();
    if(!Number.isSafeInteger(amountCents)||amountCents<1||amountCents>100000000000)throw new Error('Informe um valor de R$ 0,01 até R$ 1 bilhão.');
    const allocation=await ViaAPI.request('/allocations',{method:'POST',body:{companyId,amountCents,note,requestId}});
    if(!state.allocations.some(a=>a.id===allocation.id)){
      state.allocations.unshift(allocation);
      const company=state.companies.find(c=>c.id===allocation.companyId);
      if(company)company.balanceCents+=allocation.amountCents;
    }
  }
  async function logout(){try{await ViaAPI.logout();}finally{user=null;state={companies:[],allocations:[]};}}
  return {init,login,currentUser:()=>user,data,score,saveCompany,allocate,logout,refresh};
})();
